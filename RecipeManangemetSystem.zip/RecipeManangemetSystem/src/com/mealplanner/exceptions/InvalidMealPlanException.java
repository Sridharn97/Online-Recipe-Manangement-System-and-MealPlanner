package com.mealplanner.exceptions;

public class InvalidMealPlanException extends Exception {
    public InvalidMealPlanException(String message) {
        super(message);
    }
}
